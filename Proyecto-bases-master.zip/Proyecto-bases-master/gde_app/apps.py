from django.apps import AppConfig


class GdeAppConfig(AppConfig):
    name = 'gde_app'
