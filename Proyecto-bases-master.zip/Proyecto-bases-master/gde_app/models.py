from django.db import models

from django.utils import timezone
from django.contrib.auth.models import User


class GamesManager(models.Manager):
	def get_queryset(self):
		return super(GamesManager,self).get_queryset()

class Administrator(models.Model):
	id_admin= models.PositiveSmallIntegerField(primary_key= True)
	first_name= models.CharField(max_length=50, blank= False)
	last_name= models.CharField(max_length=50, blank= False)
	password= models.CharField(max_length=50, blank= False)
	def __str__(self):
		return '{0} {1}'.format(self.first_name, self.last_name)
	

class Category(models.Model):
	category_id= models.PositiveSmallIntegerField(primary_key= True)
	category_name= models.CharField(max_length= 20, blank= False)
	def __str__(self):
		return self.category_name

class Language(models.Model):
	language= models.CharField(max_length= 50, unique= True)
	
	def __str__(self):
		return self.language

class Genre(models.Model):
	genre= models.CharField(max_length= 50, unique= True)
	def __str__(self):
		return self.genre

class Format(models.Model):

	formats= models.CharField(max_length= 50, unique= True)
	def __str__(self):
		return self.formats
class Platform(models.Model):
	platform= models.CharField(max_length= 50, unique= True)
	
	def __str__(self):
		return self.platform

class Videogame(models.Model):
	videogame_name= models.CharField(primary_key= True, max_length= 50)
	RATING_CHOICES=(
	('Early childhood', 'EC'), 
	('Every one','E'), ('Every one 10+', 'E10+'), ('Teen', 'T'), 
	('Mature', 'M'), ('Rating Pending', 'RP'), ('Adults', 'A')
	)
	rating= models.CharField(max_length=20, choices= RATING_CHOICES, default= 'Rating Pending')
	release_date= models.DateField(blank= False)
	engine= models.CharField(max_length=50, blank= False)
	production_cost= models.DecimalField(decimal_places= 2, max_digits= 18, blank= False)
	unit_price= models.DecimalField(decimal_places= 2, max_digits= 18, blank= False)
	in_stock= models.PositiveSmallIntegerField()
	administrator= models.ForeignKey(Administrator, on_delete= models.PROTECT)
	category= models.ForeignKey(Category, on_delete= models.PROTECT, default= 2, editable= False)
	
	genre= models.ManyToManyField(Genre)
	formats= models.ManyToManyField(Format)
	platform= models.ManyToManyField(Platform)
	language= models.ManyToManyField(Language)
	def __str__(self):
		return self.videogame_name
	objects = models.Manager()
	show = GamesManager()
class Dlc(models.Model):
	dlc_name= models.CharField(primary_key= True, max_length= 50)
	videogame=  models.ForeignKey(Videogame, on_delete= models.CASCADE)
	Release_date= models.DateField()
	unit_price = models.DecimalField(decimal_places=2, max_digits=18, blank= False)
	in_stock = models.PositiveSmallIntegerField()
	administrator = models.ForeignKey(Administrator, on_delete=models.PROTECT)
	category = models.ForeignKey(Category, on_delete=models.PROTECT, default= 3, editable= False)
	def __str__(self):
		return self.dlc_name
class Package(models.Model):
	package_name= models.CharField(primary_key= True, max_length= 50)
	unit_price= models.DecimalField(decimal_places= 2, max_digits= 18, blank= False)
	administrator= models.ForeignKey(Administrator, on_delete= models.PROTECT)
	category= models.ForeignKey(Category, on_delete= models.PROTECT, default= 1, editable= False)
	in_stock= models.PositiveSmallIntegerField()
	videogames= models.ManyToManyField(Videogame)
	def __str__(self):
		return self.package_name
class Shopping_cart(models.Model):
	cart_id= models.PositiveSmallIntegerField(primary_key= True)
	expiration_date= models.DateField()
	amount= models.FloatField()
	def __str__(self):
		return 'El carro {0} expira: {1}'.format(self.cart_id, self.expiration_date)
class Shopping_cart_packages(models.Model):
	class Meta:
		unique_together = (('cart', 'package'),)
	cart= models.ForeignKey(Shopping_cart, on_delete= models.CASCADE)
	package=models.ForeignKey(Package, on_delete= models.PROTECT)
	units= models.IntegerField(blank= False)
	def __str__(self):
		return self.package
class Shopping_cart_videogames(models.Model):
	class Meta:
		unique_together = (('cart', 'videogame'),)
	cart= models.ForeignKey(Shopping_cart, on_delete= models.CASCADE)
	videogame=models.ForeignKey(Videogame, on_delete= models.PROTECT)
	units= models.IntegerField(blank= False)
	def __str__(self):
		return self.videogame
class Shopping_cart_dlc(models.Model):
	class Meta:
		unique_together = (('cart', 'dlc'),)
	cart= models.ForeignKey(Shopping_cart, on_delete= models.CASCADE)
	dlc=models.ForeignKey(Dlc, on_delete= models.PROTECT)
	units= models.IntegerField(blank= False)
	def __str__(self):
		return self.dlc

class Delivery_guy(models.Model):
	delivery_guy_id= models.PositiveSmallIntegerField(primary_key= True)
	first_name = models.CharField(max_length=50,blank=False)
	last_name = models.CharField(max_length=50, blank=False)
	telephone= models.CharField(blank= False, unique= True, max_length= 20)
	def __str__(self):
		return '{0} {1}'.format(self.first_name, self.last_name)
class State_location(models.Model):
	State= models.CharField(max_length= 50, primary_key= True)
	Zip= models.PositiveSmallIntegerField(unique= True)
class Store_location(models.Model):
	city= models.CharField(primary_key= True, max_length= 50)
	country= models.CharField(blank= False, max_length= 50)
	state= models.ForeignKey(State_location, on_delete= models.PROTECT)
	def __str__(self):
		return "{0} ({1})".format(self.ciudad, self.country)
class Store(models.Model):
	store_name= models.CharField(primary_key= True, max_length= 50)
	street_number= models.PositiveSmallIntegerField()
	street_name= models.CharField(blank= False, max_length= 50)
	email= models.EmailField()
	city= models.ForeignKey(Store_location, on_delete= models.PROTECT)
	def __str__(self):
		return self.store_name
class Store_phone(models.Model):
	class Meta:
		unique_together = (('store', 'phone'),)
	store= models.ForeignKey(Store, on_delete= models.CASCADE)
	phone= models.CharField(blank= False, unique= True, max_length= 20)

	def __str__(self):
		return self.phone



